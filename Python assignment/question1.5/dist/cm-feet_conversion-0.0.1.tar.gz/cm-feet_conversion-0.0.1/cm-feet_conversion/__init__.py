def convertCMtoFeet(num1):
    # 1 ft = 30.48 cm
    a= 30.48
    print("cm to feet :")
    return num1/a

def convertFeettoCM(num1):
    # 1 ft = 30.48 cm 
    # given cm the function convert into feet
    b= 30.48
    print("Feet to cm :")
    return num1*b

